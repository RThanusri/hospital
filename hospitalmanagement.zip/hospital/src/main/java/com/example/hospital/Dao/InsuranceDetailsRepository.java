package com.example.hospital.Dao;


import com.example.hospital.Entity.InsuranceDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InsuranceDetailsRepository extends JpaRepository<InsuranceDetails, Long> {
}
