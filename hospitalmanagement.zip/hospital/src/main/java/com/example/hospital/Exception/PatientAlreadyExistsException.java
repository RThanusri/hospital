package com.example.hospital.Exception;

public class PatientAlreadyExistsException extends RuntimeException  {

		
		public PatientAlreadyExistsException()
		{
			super("Patient Already Exists");
		}
		public PatientAlreadyExistsException(String message)
		{
			super(message);
		}


	}


