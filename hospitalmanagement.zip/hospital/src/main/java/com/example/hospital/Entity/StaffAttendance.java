package com.example.hospital.Entity;



	import jakarta.persistence.*;
	import jakarta.validation.constraints.NotNull;
	import java.time.LocalDateTime;

	@Entity
	public class StaffAttendance {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private long id;

	    @ManyToOne
	    @JoinColumn(name = "staff_id", nullable = false)
	    private Staff staff;

	    @NotNull(message = "Attendance time is required")
	    private LocalDateTime attendanceDateTime;

	    

	    public StaffAttendance() {}

	    public StaffAttendance(Staff staff, LocalDateTime attendanceDateTime) {
	        this.staff = staff;
	        this.attendanceDateTime = attendanceDateTime;
	    }

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public Staff getStaff() {
			return staff;
		}

		public void setStaff(Staff staff) {
			this.staff = staff;
		}

		public LocalDateTime getAttendanceDateTime() {
			return attendanceDateTime;
		}

		public void setAttendanceDateTime(LocalDateTime attendanceDateTime) {
			this.attendanceDateTime = attendanceDateTime;
		}

		@Override
		public String toString() {
			return "StaffAttendance [id=" + id + ", staff=" + staff + ", attendanceDateTime=" + attendanceDateTime
					+ "]";
		}

	  
	


}
