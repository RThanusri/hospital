package com.example.hospital.Service;



import com.example.hospital.Dao.InsuranceDetailsRepository;
import com.example.hospital.Dao.PatientRepository;
import com.example.hospital.Entity.InsuranceDetails;
import com.example.hospital.Entity.Patient;
import com.example.hospital.Exception.PatientNotExistsException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InsuranceDetailsService {

    @Autowired
    private InsuranceDetailsRepository insuranceDetailsRepository;
    
    @Autowired
    private PatientRepository  patientRepository;

    public InsuranceDetails saveInsuranceDetails(InsuranceDetails insuranceDetails) {
    	
  Patient patient= patientRepository.findByPatientId(insuranceDetails.getPatientId());
  if(patient==null)
  {
	  throw new PatientNotExistsException();
  }
  else {
        return insuranceDetailsRepository.save(insuranceDetails);
    }
}
}