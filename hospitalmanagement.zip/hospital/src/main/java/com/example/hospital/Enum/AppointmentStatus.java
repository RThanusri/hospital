package com.example.hospital.Enum;

public enum AppointmentStatus {
	  SCHEDULED,
	    COMPLETED,
	    CANCELLED,
	    MISSED

}
