package com.example.hospital.Entity;



import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
public class StaffSchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne
    @JoinColumn(name = "staff_id", nullable = false)
    private Staff staff;

    @Override
	public String toString() {
		return "StaffSchedule [id=" + id + ", staff=" + staff + ", shiftStart=" + shiftStart + ", shiftEnd=" + shiftEnd
				+ ", tasks=" + tasks + "]";
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Staff getStaff() {
		return staff;
	}

	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	public LocalDateTime getShiftStart() {
		return shiftStart;
	}

	public void setShiftStart(LocalDateTime shiftStart) {
		this.shiftStart = shiftStart;
	}

	public LocalDateTime getShiftEnd() {
		return shiftEnd;
	}

	public void setShiftEnd(LocalDateTime shiftEnd) {
		this.shiftEnd = shiftEnd;
	}

	public String getTasks() {
		return tasks;
	}

	public void setTasks(String tasks) {
		this.tasks = tasks;
	}

	@NotNull(message = "Shift start time is required")
    private LocalDateTime shiftStart;

    @NotNull(message = "Shift end time is required")
    private LocalDateTime shiftEnd;

    @NotBlank(message = "Tasks are required")
    private String tasks;

    

    public StaffSchedule() {}

    public StaffSchedule(Staff staff, LocalDateTime shiftStart, LocalDateTime shiftEnd, String tasks) {
        this.staff = staff;
        this.shiftStart = shiftStart;
        this.shiftEnd = shiftEnd;
        this.tasks = tasks;
    }

   
}
