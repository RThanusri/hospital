package com.example.hospital.Entity;

import java.time.LocalDate;
import java.time.LocalTime;

import com.example.hospital.Enum.AppointmentStatus;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long appointmentId;

    @NotNull(message = "Appointment date is mandatory")
    @Future(message = "Appointment date must be in the future")
    private LocalDate appointmentDate;

    @NotNull(message = "Appointment time is mandatory")
    private LocalTime appointmentTime;

    @NotNull(message = "Doctor ID is mandatory")
    private long doctorId;

    @NotNull(message = "Purpose of visit is mandatory")
    @Size(max = 255, message = "Purpose of visit must be less than 255 characters")
    private String purposeOfVisit;
    @Enumerated(EnumType.STRING)
    private AppointmentStatus status;
    private long patientId;

   
    // Constructors
    public Appointment() {
    }


	public long getAppointmentId() {
		return appointmentId;
	}


	public void setAppointmentId(long appointmentId) {
		this.appointmentId = appointmentId;
	}


	public LocalDate getAppointmentDate() {
		return appointmentDate;
	}


	public void setAppointmentDate(LocalDate appointmentDate) {
		this.appointmentDate = appointmentDate;
	}


	public LocalTime getAppointmentTime() {
		return appointmentTime;
	}


	public void setAppointmentTime(LocalTime appointmentTime) {
		this.appointmentTime = appointmentTime;
	}


	public long getDoctorId() {
		return doctorId;
	}


	public void setDoctorId(long doctorId) {
		this.doctorId = doctorId;
	}


	public String getPurposeOfVisit() {
		return purposeOfVisit;
	}


	public void setPurposeOfVisit(String purposeOfVisit) {
		this.purposeOfVisit = purposeOfVisit;
	}


	public long getPatientId() {
		return patientId;
	}


	public Appointment(long appointmentId,
			@NotNull(message = "Appointment date is mandatory") @Future(message = "Appointment date must be in the future") LocalDate appointmentDate,
			@NotNull(message = "Appointment time is mandatory") LocalTime appointmentTime,
			@NotNull(message = "Doctor ID is mandatory") long doctorId,
			@NotNull(message = "Purpose of visit is mandatory") @Size(max = 255, message = "Purpose of visit must be less than 255 characters") String purposeOfVisit,
			AppointmentStatus status, long patientId) {
		super();
		this.appointmentId = appointmentId;
		this.appointmentDate = appointmentDate;
		this.appointmentTime = appointmentTime;
		this.doctorId = doctorId;
		this.purposeOfVisit = purposeOfVisit;
		this.status = status;
		this.patientId = patientId;
	}


	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", appointmentDate=" + appointmentDate
				+ ", appointmentTime=" + appointmentTime + ", doctorId=" + doctorId + ", purposeOfVisit="
				+ purposeOfVisit + ", status=" + status + ", patientId=" + patientId + "]";
	}


	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}


	public AppointmentStatus getStatus() {
		return status;
	}


	public void setStatus(AppointmentStatus status) {
		this.status = status;
	}


	




}