package com.example.hospital.Controller;




	

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	
	import org.springframework.security.authentication.BadCredentialsException;

import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;

	import org.springframework.web.bind.annotation.RestController;

import com.example.hospital.Entity.AuthenticationRequest;
import com.example.hospital.Entity.AuthenticationResponse;
import com.example.hospital.Entity.SignupRequest;
import com.example.hospital.Entity.User;
import com.example.hospital.Service.AuthService;




@RestController

public class UserController {
	@Autowired
    private  AuthService authService;

	@PostMapping("/api/auth/signup")
	public ResponseEntity<?> signupCustomer(@RequestBody SignupRequest signupRequest) {
	    try {
	        System.out.println("Signup request received: " + signupRequest);
	        // Log the role to ensure it is being set correctly
	        System.out.println("Role received: " + signupRequest.getRole());

	        if (authService.hasCustomerWithEmail(signupRequest.getEmail())) {
	            return new ResponseEntity<>("Customer already exists", HttpStatus.NOT_ACCEPTABLE);
	        }

	        User createdCustomerDto = authService.createUser(signupRequest);

	        if (createdCustomerDto == null) {
	            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	        }

	        return new ResponseEntity<>(createdCustomerDto, HttpStatus.CREATED);
	    } catch (Exception e) {
	        System.err.println("Error during signup: " + e.getMessage());
	        e.printStackTrace();
	        return new ResponseEntity<>("Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}


	@PostMapping("/api/auth/login")
    public ResponseEntity<AuthenticationResponse> login(@RequestBody AuthenticationRequest authenticationRequest) {
        try {
            AuthenticationResponse response = authService.login(authenticationRequest);
            return ResponseEntity.ok(response);
        } catch (BadCredentialsException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null); 
        }
	}
	

}
	




