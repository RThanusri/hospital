package com.example.hospital.Entity;



import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

@Entity
public class StaffPerformance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne
    @JoinColumn(name = "staff_id", nullable = false)
    private Staff staff;

    @NotNull(message = "Number of patients seen is required")
    private int patientsSeen;

    @NotNull(message = "Feedback score is required")
    private double feedbackScore;

    

    public StaffPerformance() {}

    public StaffPerformance(Staff staff, int patientsSeen, double feedbackScore) {
        this.staff = staff;
        this.patientsSeen = patientsSeen;
        this.feedbackScore = feedbackScore;
    
}

	@Override
	public String toString() {
		return "StaffPerformance [id=" + id + ", staff=" + staff + ", patientsSeen=" + patientsSeen + ", feedbackScore="
				+ feedbackScore + "]";
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Staff getStaff() {
		return staff;
	}

	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	public int getPatientsSeen() {
		return patientsSeen;
	}

	public void setPatientsSeen(int patientsSeen) {
		this.patientsSeen = patientsSeen;
	}

	public double getFeedbackScore() {
		return feedbackScore;
	}

	public void setFeedbackScore(double feedbackScore) {
		this.feedbackScore = feedbackScore;
	}


}
