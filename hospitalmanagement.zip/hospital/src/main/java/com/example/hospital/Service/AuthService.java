package com.example.hospital.Service;

import com.example.hospital.Entity.AuthenticationRequest;
import com.example.hospital.Entity.AuthenticationResponse;
import com.example.hospital.Entity.SignupRequest;
import com.example.hospital.Entity.User;



public interface AuthService {
	User createUser(SignupRequest signupRequest);

	boolean hasCustomerWithEmail(String email);

	AuthenticationResponse login(AuthenticationRequest authRequest);

	
}

		
	





	


		
	




