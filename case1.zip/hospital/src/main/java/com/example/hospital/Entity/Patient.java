package com.example.hospital.Entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "patient")
public class Patient {

    @Id
    
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long patientId;

    @NotBlank(message = "Name is mandatory")
    @Size(max = 100, message = "Name must be less than 100 characters")
    private String name;

    @NotNull(message = "Date of birth is mandatory")
    private LocalDate dateOfBirth;

    @Min(value = 0, message = "Age must be a positive number")
    private int age;

    @NotBlank(message = "Phone number is mandatory")
    @Pattern(regexp = "\\d{10}", message = "Phone number must be exactly 10 digits")
    private String phoneNumber;

    @NotBlank(message = "Gender is mandatory")
    @Pattern(regexp = "Male|Female|Other", message = "Gender must be Male, Female, or Other")
    private String gender;

    @NotBlank(message = "Email is mandatory")
    @Email(message = "Email should be valid")
    private String email;

    @NotBlank(message = "Address is mandatory")
    @Size(max = 255, message = "Address must be less than 255 characters")
    private String address;

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Patient(long patientId,
			@NotBlank(message = "Name is mandatory") @Size(max = 100, message = "Name must be less than 100 characters") String name,
			@NotNull(message = "Date of birth is mandatory") LocalDate dateOfBirth,
			@Min(value = 0, message = "Age must be a positive number") int age,
			@NotBlank(message = "Phone number is mandatory") @Pattern(regexp = "\\d{10}", message = "Phone number must be exactly 10 digits") String phoneNumber,
			@NotBlank(message = "Gender is mandatory") @Pattern(regexp = "Male|Female|Other", message = "Gender must be Male, Female, or Other") String gender,
			@NotBlank(message = "Email is mandatory") @Email(message = "Email should be valid") String email,
			@NotBlank(message = "Address is mandatory") @Size(max = 255, message = "Address must be less than 255 characters") String address) {
		super();
		this.patientId = patientId;
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.age = age;
		this.phoneNumber = phoneNumber;
		this.gender = gender;
		this.email = email;
		this.address = address;
	}
	public Patient()
	{
		
	}

	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", name=" + name + ", dateOfBirth=" + dateOfBirth + ", age=" + age
				+ ", phoneNumber=" + phoneNumber + ", gender=" + gender + ", email=" + email + ", address=" + address
				+ "]";
	}
    

    
}