package com.example.hospital.Controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.hospital.Entity.Patient;
import com.example.hospital.Entity.Staff;
import com.example.hospital.Entity.StaffAttendance;
import com.example.hospital.Entity.StaffPerformance;
import com.example.hospital.Entity.StaffSchedule;
import com.example.hospital.Service.StaffAttendanceService;
import com.example.hospital.Service.StaffPerformanceService;
import com.example.hospital.Service.StaffScheduleService;
import com.example.hospital.Service.StaffService;

import jakarta.validation.Valid;

@RestController
public class StaffController {
	
	@Autowired
	private StaffService staffService;
	@Autowired
	private StaffAttendanceService staffAttendanceService;
	@Autowired
	private StaffPerformanceService staffPerformanceService;
	@Autowired
	private StaffScheduleService staffScheduleService;
	private static final Logger logger = LoggerFactory.getLogger(StaffController.class);

	 @PostMapping("/api/admin/registerStaff")
	    public ResponseEntity<?> registerStaff(@RequestBody @Valid Staff staff) {
	        try {
	        	
	        	Staff registeredStaff = staffService.registerStaff(staff);
	            return new ResponseEntity<>(registeredStaff, HttpStatus.CREATED);
	        } catch (Exception e) {
	            logger.error("Error registering staff: ", e);
	            return new ResponseEntity<>("An error occurred while registering the staff", HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }

     @PutMapping("/api/admin/updateStaff/{id}")
    public ResponseEntity<String> updateStaffInfo(
            @RequestBody @Valid Staff staff, @PathVariable long id) {
    	 try {
    	 String updatedStaff = staffService.updateStaff(staff,id);
    	 return ResponseEntity.ok(updatedStaff);
     } catch (Exception e) {
         logger.error("Error updating Staff: ", e);
         return new ResponseEntity<>("Staff with details provided  does not exists.", HttpStatus.INTERNAL_SERVER_ERROR);
     }
   }
     @GetMapping("/api/admin/getStaffById/{id}")
     public ResponseEntity<?> getStaffById(@PathVariable long id) {
    	 try {
         	
    		 Staff staff = staffService.getStaff(id);
             return new ResponseEntity<>(staff, HttpStatus.CREATED);
         }  catch (Exception e) { 
             
             logger.error("Error retrieving Staff: ", e); 
            
             return new ResponseEntity<>("Staff with the details provided  does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
     @DeleteMapping("/api/admin/removeStaff/{id}")
     public ResponseEntity<String> deleteStaff(@PathVariable long id) {
    	 try {
         String result = staffService.removeStaff(id);
         return new ResponseEntity<>(result, HttpStatus.OK);
    	 }
catch (Exception e) { 
             
             logger.error("Error retrieving Staff: ", e); 
            
             return new ResponseEntity<>("Staff with the details provided does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
     @GetMapping("/api/admin/getAllStaff")
     public ResponseEntity<List<Staff>> getAllStaff() {
         try {
             List<Staff> staff = staffService.getAllStaff();
             return new ResponseEntity<>(staff, HttpStatus.CREATED);
         } catch (Exception e) {
             logger.error("Error retrieving Staff: ", e);
             return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
         }
     }
     
     @PostMapping("/api/staff/staffCheckIn")
     public ResponseEntity<String> checkIn(@RequestParam long staffId) {
    	 try {
         StaffAttendance attendance = new StaffAttendance();
         attendance.setStaffId(staffId);
         attendance.setDate(LocalDate.now());
         attendance.setEntryTime(LocalTime.now());
         attendance.setEntryTime(LocalTime.now());
         

         staffAttendanceService.recordCheckIn(attendance);

         return ResponseEntity.ok("Check-in recorded successfully for staff ID: " + staffId);
    	 }
    	 catch (Exception e) {
             logger.error("Error recoding Staff checkin: ", e);
             return new ResponseEntity<>("Staff Id is not correct", HttpStatus.INTERNAL_SERVER_ERROR);
         }
    	 
     }
     @PutMapping("/api/staff/staffCheckOut")
     public ResponseEntity<String> checkOut(@RequestParam long staffId) {
         StaffAttendance attendance = staffAttendanceService.findStaffAttendanceByStaffIdAndDate(staffId, LocalDate.now());

         if (attendance != null) {
             attendance.setExitTime(LocalTime.now());
             staffAttendanceService.recordCheckOut(attendance);
             return ResponseEntity.ok("Check-out recorded successfully for staff ID: " + staffId);
         } else {
             return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No check-in record found for staff ID: " + staffId);
         }
     }
   
     
     @DeleteMapping("api/admin/removeAttendance")
     public ResponseEntity<String> deleteAttendance(@RequestParam long staffId, @RequestParam LocalDate date){
    	 try {
         String result = staffAttendanceService.removeAttendance(staffId,date);
         return new ResponseEntity<>(result, HttpStatus.OK);
    	 }
catch (Exception e) { 
             
             logger.error("Error deleting Attendance: ", e); 
            
             return new ResponseEntity<>("Attendance record with the details provided does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
     @GetMapping("/api/staff/getAllStaffAttendanceById/{staffId}")
     public ResponseEntity<List<StaffAttendance>> getAllStaffAttendanceById(@PathVariable long staffId) {
    	 try {
         	
    		List< StaffAttendance> staffAttendance = staffAttendanceService.getAllStaffAttendanceById(staffId);
             return new ResponseEntity<>(staffAttendance, HttpStatus.CREATED);
         }  catch (Exception e) { 
             
             logger.error("Error retrieving Staff: ", e); 
            
             return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
     
     @GetMapping("/api/staff/getAllStaffAttendanceByDate/{date}")
     public ResponseEntity<List<StaffAttendance>> getAllStaffAttendanceByDate(@PathVariable LocalDate date) {
    	 try {
         	
    		List< StaffAttendance> staffAttendance = staffAttendanceService.getAllStaffAttendanceByDate(date);
             return new ResponseEntity<>(staffAttendance, HttpStatus.CREATED);
         }  catch (Exception e) { 
             
             logger.error("Error retrieving Staff: ", e); 
            
             return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
     
     @GetMapping("/api/staff/getAllStaffAttendanceByDateAndId/{date}/{staffId}")
     public ResponseEntity<List<StaffAttendance>> getAllStaffAttendanceByDateAndId(@PathVariable LocalDate date, @PathVariable Long staffId) {
    	 try {
         	
    		List< StaffAttendance> staffAttendance = staffAttendanceService.getAllStaffAttendanceByDateAndId(date,staffId);
             return new ResponseEntity<>(staffAttendance, HttpStatus.CREATED);
         }  catch (Exception e) { 
             
             logger.error("Error retrieving Staff: ", e); 
            
             return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
     
     @PostMapping("/api/admin/inputStaffPerformance")
	    public ResponseEntity<?> inputStaffPerformance(@RequestBody @Valid StaffPerformance staffPerformance) {
	        try {
	        	
	        	StaffPerformance inputedStaffPerformance = staffPerformanceService.inputStaffPerformance(staffPerformance);
	            return new ResponseEntity<>(inputedStaffPerformance, HttpStatus.CREATED);
	        } catch (Exception e) {
	            logger.error("Error inputting staff performance: ", e);
	            return new ResponseEntity<>("An error occurred while entering the staff performance", HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }

     @PutMapping("/api/admin/updateStaffPerformance/{staffId}")
    public ResponseEntity<String> updateStaffPerformanceInfo(
            @RequestBody @Valid StaffPerformance staffPerformance, @PathVariable long staffId) {
    	 try {
    	 String updatedStaffPerformance = staffPerformanceService.updateStaffPerformance(staffPerformance,staffId);
    	 return ResponseEntity.ok(updatedStaffPerformance);
     } catch (Exception e) {
         logger.error("Error updating Staff Performance: ", e);
         return new ResponseEntity<>("Staff with details provided  does not exists.", HttpStatus.INTERNAL_SERVER_ERROR);
     }
    	 
   }
     @GetMapping("/api/admin/getStaffPerformanceById/{staffId}")
     public ResponseEntity<?> getStaffPerformanceById(@PathVariable long staffId) {
    	 try {
         	
    		 StaffPerformance staffPerformance = staffPerformanceService.getStaffPerformance(staffId);
             return new ResponseEntity<>(staffPerformance, HttpStatus.CREATED);
         }  catch (Exception e) { 
             
             logger.error("Error retrieving Staff Performance: ", e); 
            
             return new ResponseEntity<>("Staff with the details provided  does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
     @DeleteMapping("/api/admin/removeStaffPerformance/{staffId}")
     public ResponseEntity<String> deleteStaffPerformance(@PathVariable long staffId) {
    	 try {
         String result = staffPerformanceService.removeStaffPerformance(staffId);
         return new ResponseEntity<>(result, HttpStatus.OK);
    	 }
catch (Exception e) { 
             
             logger.error("Error retrieving Staff: ", e); 
            
             return new ResponseEntity<>("Staff with the details provided does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
     @GetMapping("/api/admin/getAllStaffPerformance")
     public ResponseEntity<List<StaffPerformance>> getAllStaffPerformance() {
         try {
             List<StaffPerformance> staffPerformance = staffPerformanceService.getAllStaffPerformance();
             return new ResponseEntity<>(staffPerformance, HttpStatus.CREATED);
         } catch (Exception e) {
             logger.error("Error retrieving Staff: ", e);
             return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
         }
     }
     
     @PostMapping("/api/admin/scheculeStaffDailyTasks")
	    public ResponseEntity<?> scheduleStaffTaks(@RequestBody @Valid StaffSchedule staffSchedule) {
	        try {
	        	
	        	StaffSchedule staffDailySchedule = staffScheduleService.scheduleStaffTaks(staffSchedule);
	            return new ResponseEntity<>(staffDailySchedule, HttpStatus.CREATED);
	        } catch (Exception e) {
	            logger.error("Error scheduling staff task: ", e);
	            return new ResponseEntity<>("Validation fails", HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }
     
     @PutMapping("/api/admin/updateStaffSchedule/{staffId}/{date}")
    
     public ResponseEntity<String> StaffScheduleService(
             @PathVariable long staffId,
             @PathVariable String date,
             @RequestBody StaffSchedule updatedSchedule) {
    	 try {

         LocalDate scheduleDate = LocalDate.parse(date, DateTimeFormatter.ISO_DATE);
         String updated = staffScheduleService. updateStaffScheduleForDay(staffId, scheduleDate, updatedSchedule);
         return ResponseEntity.ok(updated);
    	 }
         catch (Exception e) {
	            logger.error("Error updating staff task: ", e);
	            return new ResponseEntity<>("Staff Id or schedule not found for the given date", HttpStatus.INTERNAL_SERVER_ERROR);
	        }
    	 
     }
     @GetMapping("/api/admin/getAllStaffSchedule")
     public ResponseEntity<List<StaffSchedule>> getAllStaffSchedule() {
         try {
             List<StaffSchedule> staffSchedule = staffScheduleService.getAllStaffSchedule();
             return new ResponseEntity<>(staffSchedule, HttpStatus.CREATED);
         } catch (Exception e) {
             logger.error("Error retrieving Staff Schedule: ", e);
             return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
         }
     }
     
     @GetMapping("/api/admin/getStaffScheduleById/{staffId}")
     public ResponseEntity<?> getStaffScheduleById(@PathVariable long staffId) {
    	 try {
         	
    		 List<StaffSchedule> staffSchedule = staffScheduleService.getAllStaffScheduleById(staffId);
             return new ResponseEntity<>(staffSchedule, HttpStatus.CREATED);
         }  catch (Exception e) { 
             
             logger.error("Error retrieving Staff Schedule: ", e); 
            
             return new ResponseEntity<>("Staff with the details provided  does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
     
     @GetMapping("/api/admin/getStaffScheduleByIdAndDate/{staffId}/{date}")
     public ResponseEntity<?> getStaffScheduleByIdAndDate(@PathVariable long staffId,@PathVariable String date) {
    	 try {
    		 LocalDate scheduleDate = LocalDate.parse(date, DateTimeFormatter.ISO_DATE);
         	
    		 StaffSchedule staffSchedule = staffScheduleService.getStaffScheduleByIdAndDate(staffId,scheduleDate);
             return new ResponseEntity<>(staffSchedule, HttpStatus.CREATED);
         }  catch (Exception e) { 
             
             logger.error("Error retrieving Staff Schedule: ", e); 
            
             return new ResponseEntity<>("Staff with the details provided  does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
     @DeleteMapping("/api/admin/removeStaffSchedule/{staffId}/{date}")
     public ResponseEntity<String> deleteStaffPerformance(@PathVariable long staffId, @PathVariable String date) {
    	 try {
    		 LocalDate scheduleDate = LocalDate.parse(date, DateTimeFormatter.ISO_DATE);
         String result = staffScheduleService.removeStaffSchedule(staffId,scheduleDate);
         return new ResponseEntity<>(result, HttpStatus.OK);
    	 }
catch (Exception e) { 
             
             logger.error("Error retrieving Staff: ", e); 
            
             return new ResponseEntity<>("Staff with the details provided does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
}
