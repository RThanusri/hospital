package com.example.hospital.Exception;

public class StaffAlreadyExistsException extends RuntimeException  {

	
	public StaffAlreadyExistsException()
	{
		super("Staff with the details provided Already Exists");
	}
	public StaffAlreadyExistsException(String message)
	{
		super(message);
	}

}
