package com.example.hospital.Dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.hospital.Entity.StaffSchedule;

@Repository
public interface StaffScheduleRepository extends JpaRepository<StaffSchedule,Long> {

	 @Query(value = "SELECT s FROM StaffSchedule s WHERE s.staffId = :staffId AND FUNCTION('DATE', s.shiftStart) = :date")
	   StaffSchedule findByStaffIdAndDate(@Param("staffId") long staffId, @Param("date") LocalDate date);

	List findAllByStaffId(long staffId);

	@Modifying
	@Query(value = "DELETE FROM StaffSchedule s WHERE s.staffId = :staffId AND FUNCTION('DATE', s.shiftStart) = :date")
	void deleteByStaffIdAndDate(@Param("staffId") long staffId, @Param("date") LocalDate date);

}
