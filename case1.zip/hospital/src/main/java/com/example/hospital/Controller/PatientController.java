package com.example.hospital.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.MethodArgumentNotValidException;


import com.example.hospital.Entity.InsuranceDetails;
import com.example.hospital.Entity.MedicalHistory;
import com.example.hospital.Entity.Patient;
import com.example.hospital.Entity.Staff;
import com.example.hospital.Service.InsuranceDetailsService;
import com.example.hospital.Service.MedicalHistoryService;
import com.example.hospital.Service.PatientService;

import jakarta.validation.Valid;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
public class PatientController {

    private static final Logger logger = LoggerFactory.getLogger(PatientController.class);

    @Autowired
    private PatientService patientService;

    @Autowired
    private MedicalHistoryService medicalHistoryService;

    @PostMapping("/api/admin/registerPatient")
    public ResponseEntity<?> registerPatient(@RequestBody @Valid Patient patient) {
        try {
        	
            Patient registeredPatient = patientService.registerPatient(patient);
            return new ResponseEntity<>(registeredPatient, HttpStatus.CREATED);
        } catch (Exception e) {
            logger.error("Error registering patient: ", e);
            return new ResponseEntity<>("An error occurred while registering the patient.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @Autowired
    private InsuranceDetailsService insuranceDetailsService;
    
     @PutMapping("/api/admin/updatePatient/{patientId}")
    public ResponseEntity<String> updatePatientInfo(
            @RequestBody @Valid Patient patient, @PathVariable long patientId) {
    	 try {
    	 String updatePatient = patientService.updatePatient(patient,patientId);
    	 return ResponseEntity.ok(updatePatient);
     } catch (Exception e) {
         logger.error("Error updating patient: ", e);
         return new ResponseEntity<>("Patient does not exists.", HttpStatus.INTERNAL_SERVER_ERROR);
     }
   }

     @GetMapping("/api/admin/getPatientById/{patientId}")
     public ResponseEntity<?> getPatientById(@PathVariable long patientId) {
    	 try {
         	
             Patient patient = patientService.getPatient(patientId);
             return new ResponseEntity<>(patient, HttpStatus.CREATED);
         }  catch (Exception e) { 
             
             logger.error("Error retrieving patient: ", e); 
            
             return new ResponseEntity<>("Patient does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
     @GetMapping("/api/admin/getAllPatient")
     public ResponseEntity<List<Patient>> getAllPatient() {
         try {
             List<Patient> patient = patientService.getAllPatient();
             return new ResponseEntity<>(patient, HttpStatus.CREATED);
         } catch (Exception e) {
             logger.error("Error retrieving patient: ", e);
             return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
         }
     }

     @DeleteMapping("/api/admin/removePatient/{patientId}")
     public ResponseEntity<String> deletePatient(@PathVariable long patientId) {
    	 try {
         String result = patientService.removePatient(patientId);
         return new ResponseEntity<>(result, HttpStatus.OK);
    	 }
catch (Exception e) { 
             
             logger.error("Error retrieving patient: ", e); 
            
             return new ResponseEntity<>("Patient does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
         }
         } 
     
    @PostMapping("/api/admin/addInsurance")
    public ResponseEntity<InsuranceDetails> addInsuranceDetails(
             @RequestBody @Valid InsuranceDetails insuranceDetails) {
        try {
            InsuranceDetails savedInsuranceDetails = insuranceDetailsService.saveInsuranceDetails(insuranceDetails);
            return new ResponseEntity<>(savedInsuranceDetails, HttpStatus.CREATED);
        } catch (Exception e) {
        	 logger.error("Error adding patient: ", e);
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }
    @PutMapping("/api/admin/updateInsuranceInfo/{id}")
    public ResponseEntity<String> updateInsuranceInfo(
            @RequestBody @Valid InsuranceDetails insurance, @PathVariable long id) {
    	 try {
    	 String updateInsurance = insuranceDetailsService.updateInsuranceInfo(insurance,id);
    	 return ResponseEntity.ok(updateInsurance);
     } catch (Exception e) {
         logger.error("Error updating insurance: ", e);
         return new ResponseEntity<>("Insurance details with this ID do not exist", HttpStatus.INTERNAL_SERVER_ERROR);
     }
    }
    @GetMapping("/api/admin/getInsuranceDetailsById/{id}")
    public ResponseEntity<?> getInsuranceDetailsById(@PathVariable long id) {
   	 try {
        	
   		InsuranceDetails insuranceDetails = insuranceDetailsService.getInsuranceDetailsById(id);
            return new ResponseEntity<>(insuranceDetails, HttpStatus.CREATED);
        }  catch (Exception e) { 
            
            logger.error("Error retrieving patient: ", e); 
           
            return new ResponseEntity<>("Insurance details with this ID do not exist", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        } 

    @DeleteMapping("/api/admin/removeInsuranceDetails/{id}")
    public ResponseEntity<String> deleteInsuranceDetails(@PathVariable long id) {
   	 try {
        String result = insuranceDetailsService.removeInsuranceDetails(id);
        return new ResponseEntity<>(result, HttpStatus.OK);
   	 }
catch (Exception e) { 
            
            logger.error("Error retrieving patient: ", e); 
           
            return new ResponseEntity<>("Patient does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        } 
    @PostMapping("/api/admin/addMedicalHistory")
    public ResponseEntity<MedicalHistory> addMedicalHistory(
             @RequestBody @Valid MedicalHistory medicalHistory) {
        try {
        	MedicalHistory savedMedicalHistory = medicalHistoryService.addMedicalHistory(medicalHistory);
            return new ResponseEntity<>(savedMedicalHistory, HttpStatus.CREATED);
        } catch (Exception e) {
        	 logger.error("Error adding medical history ", e);
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }
    @PutMapping("/api/admin/updateMedicalHistory/{medicalHistoryId}")
    public ResponseEntity<String> updateMedicalHistory(
            @RequestBody @Valid MedicalHistory medicalHistory, @PathVariable long medicalHistoryId) {
    	 try {
    	 String updatedMedicalHistory = medicalHistoryService.updateMedicalHistory(medicalHistory,medicalHistoryId);
    	 return ResponseEntity.ok(updatedMedicalHistory);
     } catch (Exception e) {
         logger.error("Error updating MedicalHistory: ", e);
         return new ResponseEntity<>("MedicalHistory with this ID do not exist", HttpStatus.INTERNAL_SERVER_ERROR);
     }
    }
    
    @GetMapping("/api/admin/getMedicalHistoryById/{medicalHistoryId}")
    public ResponseEntity<?> getMedicalHistoryById(@PathVariable long medicalHistoryId) {
   	 try {
        	
   		MedicalHistory medicalHistory =medicalHistoryService.getMedicalHistoryById(medicalHistoryId);
            return new ResponseEntity<>(medicalHistory, HttpStatus.CREATED);
        }  catch (Exception e) { 
            
            logger.error("Error retrieving MedicalHistory: ", e); 
           
            return new ResponseEntity<>("MedicalHistory with this ID do not exist", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        } 
    @DeleteMapping("/api/admin/removeMedicalHistory/{medicalHistoryId}")
    public ResponseEntity<String> deleteMedicalHistory(@PathVariable long medicalHistoryId) {
   	 try {
        String result = medicalHistoryService.removeMedicalHistory(medicalHistoryId);
        return new ResponseEntity<>(result, HttpStatus.OK);
   	 }
catch (Exception e) { 
            
            logger.error("Error deleting Medical History: ", e); 
           
            return new ResponseEntity<>(" MedicalHistory with this ID do not exists", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        } 
}

   
