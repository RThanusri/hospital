package com.example.hospital.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hospital.Dao.StaffRepository;
import com.example.hospital.Dao.StaffScheduleRepository;
import com.example.hospital.Entity.Staff;
import com.example.hospital.Entity.StaffPerformance;
import com.example.hospital.Entity.StaffSchedule;
import com.example.hospital.Exception.StaffNotExistsException;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Service
public class StaffScheduleService {
	@Autowired
	private StaffRepository staffRepository;
	
	@Autowired
	private StaffScheduleRepository staffScheduleRepository;

	public StaffSchedule scheduleStaffTaks(@Valid StaffSchedule staffSchedule) {
		Staff existingStaff = staffRepository.findById(staffSchedule.getStaffId()).orElse(null);
		  if (existingStaff == null) {
	        	
	            throw new StaffNotExistsException("Staff with the details provided does not  exists.");
	        } 
	        else {
	        
	        	StaffSchedule savedStaffSchedule =staffScheduleRepository.save(staffSchedule);
	           
	            return savedStaffSchedule;
	            }
	           
	        }

    public String updateStaffScheduleForDay(long staffId, LocalDate date, StaffSchedule updatedSchedule) {
        StaffSchedule schedule = staffScheduleRepository.findByStaffIdAndDate(staffId, date);

        if(schedule==null)
        { throw new RuntimeException("StaffSchedule not found for staff ID: " + staffId + " on date: " + date);
        }
        else
        {
        	
            schedule.setShiftStart(updatedSchedule.getShiftStart());
            schedule.setShiftEnd(updatedSchedule.getShiftEnd());
            schedule.setTasks(updatedSchedule.getTasks());
             staffScheduleRepository.save(schedule);
             return "Schedule updated successfully";
        }

       
    }

	public List<StaffSchedule> getAllStaffSchedule() {
		 return staffScheduleRepository.findAll().stream()
	                
	                .collect(Collectors.toList());
	}

	public List<StaffSchedule> getAllStaffScheduleById(long staffId) {
		List  schedule = staffScheduleRepository.findAllByStaffId(staffId);

        if(schedule==null)
        { throw new StaffNotExistsException();
        }
        else
        {
        	return schedule;
        	
	}
	
		
	}

	public StaffSchedule getStaffScheduleByIdAndDate(long staffId, LocalDate scheduleDate) {
		StaffSchedule schedule = staffScheduleRepository.findByStaffIdAndDate(staffId, scheduleDate);

        if(schedule==null)
        { throw new RuntimeException("StaffSchedule not found for staff ID: " + staffId + " on date: " + scheduleDate);
        }
        else
        {
        	return schedule;
        }
	}
@Transactional
	public String removeStaffSchedule(long staffId, LocalDate scheduleDate) {

		StaffSchedule schedule = staffScheduleRepository.findByStaffIdAndDate(staffId, scheduleDate);

        if(schedule==null)
        { throw new RuntimeException("StaffSchedule not found for staff ID: " + staffId + " on date: " + scheduleDate);
        }
        else
        {
        	staffScheduleRepository.deleteByStaffIdAndDate(staffId,scheduleDate);
        	return "Staff Schedule removed succesffully";
        }
	}


}