package com.example.hospital.Dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.hospital.Entity.Appointment;
import com.example.hospital.Entity.Staff;

public interface AppointmentRepository extends JpaRepository<Appointment,Long>{

	List<Appointment> findByDoctorIdAndAppointmentDate(long doctorId, LocalDate date);

	List<Appointment> findAllByAppointmentDate(LocalDate date);

	List<Appointment> findAllByPatientId(long patientId);

	List<Appointment> findAllByDoctorId(long doctorId);

	List<Appointment> findAllByDoctorIdAndAppointmentDate(long doctorId,LocalDate date);

}
