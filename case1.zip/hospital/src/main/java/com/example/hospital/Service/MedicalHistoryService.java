package com.example.hospital.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.hospital.Dao.MedicalHistoryRepository;
import com.example.hospital.Dao.PatientRepository;
import com.example.hospital.Entity.InsuranceDetails;
import com.example.hospital.Entity.MedicalHistory;
import com.example.hospital.Entity.Patient;
import com.example.hospital.Exception.InsuranceNotFoundException;
import com.example.hospital.Exception.MedicalHistoryNotFoundException;
import com.example.hospital.Exception.PatientAlreadyExistsException;
import com.example.hospital.Exception.PatientNotExistsException;

import jakarta.validation.Valid;
@Service
public class MedicalHistoryService {
	@Autowired
    
    private PatientRepository patientRepository;
@Autowired
    
    private MedicalHistoryRepository medicalHistoryRepository;
	@Transactional
    public  MedicalHistory addMedicalHistory(MedicalHistory medicalHistory) {
		 Patient patient= patientRepository.findByPatientId(medicalHistory.getPatientId());
        if (patient == null) {
        	
            throw new PatientNotExistsException("Patient with this id does not exists.");
        } 
        else {
        	
        	MedicalHistory savedMedicalHistory = medicalHistoryRepository.save(medicalHistory);
           
            return savedMedicalHistory;
            }
           
        }
	public String updateMedicalHistory(@Valid MedicalHistory medicalHistory, long medicalHistoryId) {
		  MedicalHistory existingMedicalHistory = medicalHistoryRepository.findById(medicalHistoryId)
	                .orElseThrow(() -> new MedicalHistoryNotFoundException("Medical history with this ID does not exist."));

	        existingMedicalHistory.setAllergies(medicalHistory.getAllergies());
	        existingMedicalHistory.setKnownDiseases(medicalHistory.getKnownDiseases());
	        existingMedicalHistory.setPastTreatments(medicalHistory.getPastTreatments());
	        existingMedicalHistory.setCurrentTreatments(medicalHistory.getCurrentTreatments());
	        existingMedicalHistory.setLastCheckUpDate(medicalHistory.getLastCheckUpDate());
	        existingMedicalHistory.setFamilyMedicalHistory(medicalHistory.getFamilyMedicalHistory());

	         medicalHistoryRepository.save(existingMedicalHistory);
	            return "Insurance details updated successfully:";
	        }
	public MedicalHistory getMedicalHistoryById(long medicalHistoryId) {
		MedicalHistory medicalHistory = medicalHistoryRepository.findById(medicalHistoryId)
                .orElseThrow(() -> new InsuranceNotFoundException("Insurance details with this ID do not exist."));
        return  medicalHistory;
	
		
	}
	public String removeMedicalHistory(long medicalHistoryId) {
		if(medicalHistoryRepository.existsById(medicalHistoryId))
		
		{
			medicalHistoryRepository.deleteById(medicalHistoryId);
			return"Medical History Removed Successfully";
		}
		return "Medical History with this ID do not exist.";
	
	}
	   


}
