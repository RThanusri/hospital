package com.example.hospital.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.hospital.Entity.MedicalHistory;

public interface MedicalHistoryRepository extends JpaRepository<MedicalHistory,Long>{

	MedicalHistory findByPatientId(long patientId);

}
