package com.example.hospital.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hospital.Dao.AppointmentRepository;
import com.example.hospital.Dao.DoctorAppointmentScheduleRepository;
import com.example.hospital.Dao.PatientRepository;
import com.example.hospital.Dao.StaffRepository;
import com.example.hospital.Entity.Appointment;
import com.example.hospital.Entity.DoctorAppointmentSchedule;
import com.example.hospital.Entity.Staff;
import com.example.hospital.Entity.StaffSchedule;
import com.example.hospital.Enum.AppointmentStatus;
import com.example.hospital.Exception.DoctorNotFoundException;
import com.example.hospital.Exception.StaffNotExistsException;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Service
	public class AppointmentService {

	    @Autowired
	    private AppointmentRepository appointmentRepository;
	    
	    @Autowired
	    private StaffRepository staffRepository;
	    
	    @Autowired
	    private PatientRepository patientRepository;

	    @Autowired
	    private DoctorAppointmentScheduleRepository doctorScheduleRepository;
	    
	    public DoctorAppointmentSchedule scheduleDoctorAppointment(@Valid DoctorAppointmentSchedule doctorAppointmentSchedule) {
			Staff existingStaff = staffRepository.findById(doctorAppointmentSchedule.getDoctorId()).orElse(null);
			  if (existingStaff == null) {
		        	
		            throw new DoctorNotFoundException("Doctor with the details provided does not  exists.");
		        } 
		        else {
		        
		        	DoctorAppointmentSchedule savedDoctorAppointmentSchedule =doctorScheduleRepository.save(doctorAppointmentSchedule);
		           
		            return savedDoctorAppointmentSchedule;
		            }
		           
		        }

	    public String updateDoctorAppointmentScheduleForDay(long doctorId, LocalDate date, DoctorAppointmentSchedule updatedSchedule) {
	    	DoctorAppointmentSchedule schedule = doctorScheduleRepository.findByDoctorIdAndDate(doctorId, date);

	        if(schedule==null)
	        { throw new RuntimeException("Doctor Schedule not found for doctor ID: " + doctorId + " on date: " + date);
	        }
	        else
	        {
	        	
	            schedule.setStartTime(updatedSchedule.getStartTime());
	            schedule.setEndTime(updatedSchedule.getEndTime());
	            schedule.setDate(updatedSchedule.getDate());
	            doctorScheduleRepository.save(schedule);
	             return "Schedule updated successfully";
	        }

	       
	    }
	    @Transactional
		public String removeDoctorAppointmentSchedule(long doctorId, LocalDate scheduleDate) {

			DoctorAppointmentSchedule schedule = doctorScheduleRepository.findByDoctorIdAndDate(doctorId, scheduleDate);

	        if(schedule==null)
	        { throw new RuntimeException("Schedule not found for doctor ID: " + doctorId + " on date: " + scheduleDate);
	        }
	        else
	        {
	        	doctorScheduleRepository.deleteByDoctorIdAndDate(doctorId,scheduleDate);
	        	return "Doctor Schedule removed succesffully";
	        }
		}
	    public List<DoctorAppointmentSchedule> getAllDoctorSchedules() {
	        return doctorScheduleRepository.findAll().stream()
	                                       .collect(Collectors.toList());
	    }

	    public List<DoctorAppointmentSchedule> getDoctorSchedulesByDoctorId(long doctorId) {
	        List<DoctorAppointmentSchedule> schedule = doctorScheduleRepository.findAllByDoctorId(doctorId);

	        if (schedule == null) {
	            throw new RuntimeException("Schedules not found for doctor ID: " + doctorId);
	        } else {
	            return schedule;
	        }
	    }

	    public DoctorAppointmentSchedule getDoctorScheduleByDate(long doctorId, LocalDate scheduleDate) {
	        DoctorAppointmentSchedule schedule = doctorScheduleRepository.findByDoctorIdAndDate(doctorId, scheduleDate);

	        if (schedule == null) {
	            throw new RuntimeException("DoctorSchedule not found for doctor ID: " + doctorId + " on date: " + scheduleDate);
	        } else {
	            return schedule;
	        }
	    }



	    public boolean isDoctorAvailable(long doctorId, LocalDate date, LocalTime desiredTime) {
	        
	        DoctorAppointmentSchedule schedule = doctorScheduleRepository. findByDoctorIdAndDate(doctorId, date);

	       
	        if (schedule == null) {
	            return false; 
	        }

	       
	        if (desiredTime.isBefore(schedule.getStartTime()) && desiredTime.isAfter(schedule.getEndTime())) {
	            return false;
	        }
	   
	        List<Appointment> appointments = appointmentRepository. findByDoctorIdAndAppointmentDate(doctorId, date);

	     
	        for (Appointment appointment : appointments) {
	            if (appointment.getAppointmentTime().equals(desiredTime)) {
	                return false; 
	            }
	        }

	        return true;
	       
	        }

	    public Appointment scheduleAppointment(Appointment appointment) {
	
	        if (!staffRepository.existsById(appointment.getDoctorId())) {
	            throw new RuntimeException("Doctor with ID " + appointment.getDoctorId() + " does not exist.");
	        }

	        if (!patientRepository.existsById(appointment.getPatientId())) {
	            throw new RuntimeException("Patient with ID " + appointment.getPatientId() + " does not exist.");
	        }

	        
	        if (isDoctorAvailable(appointment.getDoctorId(), appointment.getAppointmentDate(), appointment.getAppointmentTime())) {
	            appointment.setStatus(AppointmentStatus.SCHEDULED);
	            return appointmentRepository.save(appointment);
	        } else {
	            throw new RuntimeException("Doctor is not available at the requested time.");
	        }
	    }
	    @Transactional
	    public String cancelAppointment(long appointmentId) {
	        
	        Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
	        
	        if (appointment == null) {
	            throw new RuntimeException("Appointment with ID " + appointmentId + " does not exist.");
	        }
	        
	      
	        if (appointment.getStatus() == AppointmentStatus.CANCELLED) {
	            throw new RuntimeException("Appointment is already canceled.");
	        }
	        
	        
	        appointmentRepository.deleteById(appointmentId);
	        
	        
	       
	        
	      
	        
	        
	        return "Appointment cancelled";
	    }
	  
	    
	    public List<Appointment> getAllAppointmentsByDate(LocalDate date)
	    {
	    	
	    	return appointmentRepository.findAllByAppointmentDate(date).stream()
	                
	                .collect(Collectors.toList());
	    }


	    
	    public Appointment updateAppointment(Appointment appointment,long appointmentId) {
	    	
	    	if(!appointmentRepository.existsById(appointmentId))
	    	{
	    		 throw new RuntimeException("appointment with ID " + appointment.getDoctorId() + " does not exist.");
	        }
	    	
	    	
	        if (!staffRepository.existsById(appointment.getDoctorId())) {
	            throw new RuntimeException("Doctor with ID " + appointment.getDoctorId() + " does not exist.");
	        }

	        if (!patientRepository.existsById(appointment.getPatientId())) {
	            throw new RuntimeException("Patient with ID " + appointment.getPatientId() + " does not exist.");
	        }

	        
	        if (isDoctorAvailable(appointment.getDoctorId(), appointment.getAppointmentDate(), appointment.getAppointmentTime())) {
	            appointment.setStatus(AppointmentStatus.SCHEDULED);
	            return appointmentRepository.save(appointment);
	        } else {
	            throw new RuntimeException("Doctor is not available at the requested time.");
	        }
	    }

		public List<Appointment> getAllAppointmentsByPatientId(long patientId) {
              return appointmentRepository.findAllByPatientId(patientId).stream()
	                
	                .collect(Collectors.toList());
	    }

		public List<Appointment> getAllAppointmentsByDoctorId(long doctorId) {
		
			return appointmentRepository.findAllByDoctorId(doctorId).stream()
	                
	                .collect(Collectors.toList());
		}

		public List<Appointment> getAllAppointmentsByDoctorIdAndDate(long doctorId, LocalDate date) {
			
	return appointmentRepository.findAllByDoctorIdAndAppointmentDate(doctorId,date).stream()
	                
	                .collect(Collectors.toList());
		}
			
	}



