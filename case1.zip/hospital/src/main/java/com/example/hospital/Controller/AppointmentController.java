package com.example.hospital.Controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.hospital.Entity.Appointment;
import com.example.hospital.Entity.DoctorAppointmentSchedule;
import com.example.hospital.Entity.StaffAttendance;
import com.example.hospital.Entity.StaffSchedule;
import com.example.hospital.Service.AppointmentService;

import jakarta.validation.Valid;

@RestController

public class AppointmentController {
	private static final Logger logger = LoggerFactory.getLogger(StaffController.class);

    @Autowired
    private AppointmentService appointmentService;
    

    @PostMapping("/api/staff/scheduleAppointment")
    public ResponseEntity<String> scheduleAppointment(@RequestBody Appointment appointment) {
        try {
            Appointment scheduledAppointment = appointmentService.scheduleAppointment(appointment);
            return new ResponseEntity<>("Appointment scheduled successfully with ID: " + scheduledAppointment.getAppointmentId(), HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/api/staff/updateAppointment/{appointmentId}")
    public ResponseEntity<String> updateAppointment(@RequestBody Appointment appointment, @PathVariable long appointmentId) {
        try {
            Appointment scheduledAppointment = appointmentService.updateAppointment(appointment, appointmentId);
            return new ResponseEntity<>("Appointment updated successfully with ID: " + scheduledAppointment.getAppointmentId(), HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    
    @PostMapping("/api/admin/scheculeDoctorDailyTasks")
    public ResponseEntity<?> scheduleDoctorTaks(@RequestBody @Valid DoctorAppointmentSchedule schedule) {
        try {
        	
        	DoctorAppointmentSchedule dailySchedule = appointmentService.scheduleDoctorAppointment(schedule);
            return new ResponseEntity<>(dailySchedule, HttpStatus.CREATED);
        } catch (Exception e) {
            logger.error("Error scheduling staff task: ", e);
            return new ResponseEntity<>("Validation fails", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
 
 @PutMapping("/api/admin/updateDoctorAppointmentScheduleForDay/{doctorId}/{date}")

 public ResponseEntity<String> updateDoctorAppointmentScheduleForDay(
         @PathVariable long doctorId,
         @PathVariable String date,
         @RequestBody DoctorAppointmentSchedule updatedSchedule) {
	 try {

     LocalDate scheduleDate = LocalDate.parse(date, DateTimeFormatter.ISO_DATE);
     String updated = appointmentService. updateDoctorAppointmentScheduleForDay(doctorId, scheduleDate, updatedSchedule);
     return ResponseEntity.ok(updated);
	 }
     catch (Exception e) {
            logger.error("Error updating staff task: ", e);
            return new ResponseEntity<>("Staff Id or schedule not found for the given date", HttpStatus.INTERNAL_SERVER_ERROR);
        }
	 
 }
 @GetMapping("/api/admin/getAllDoctorSchedule")
 public ResponseEntity<List<DoctorAppointmentSchedule>> getAllDoctorSchedule() {
     try {
         List<DoctorAppointmentSchedule> doctorSchedule = appointmentService.getAllDoctorSchedules();
         return new ResponseEntity<>(doctorSchedule, HttpStatus.OK);
     } catch (Exception e) {
         logger.error("Error retrieving Doctor Schedule: ", e);
         return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
     }
 }

 @GetMapping("/api/admin/getDoctorScheduleByDoctorId/{doctorId}")
 public ResponseEntity<?> getDoctorScheduleByDoctorId(@PathVariable long doctorId) {
     try {
         List<DoctorAppointmentSchedule> doctorSchedule = appointmentService.getDoctorSchedulesByDoctorId(doctorId);
         return new ResponseEntity<>(doctorSchedule, HttpStatus.OK);
     } catch (Exception e) {
         logger.error("Error retrieving Doctor Schedule: ", e);
         return new ResponseEntity<>("Doctor with the details provided does not exist.", HttpStatus.INTERNAL_SERVER_ERROR);
     }
 }

 @GetMapping("/api/admin/getDoctorScheduleByDate/{doctorId}/{date}")
 public ResponseEntity<?> getDoctorScheduleByDate(@PathVariable long doctorId, @PathVariable String date) {
     try {
         LocalDate scheduleDate = LocalDate.parse(date, DateTimeFormatter.ISO_DATE);
         DoctorAppointmentSchedule doctorSchedule = appointmentService.getDoctorScheduleByDate(doctorId, scheduleDate);
         return new ResponseEntity<>(doctorSchedule, HttpStatus.OK);
     } catch (Exception e) {
         logger.error("Error retrieving Doctor Schedule: ", e);
         return new ResponseEntity<>("Doctor with the details provided does not exist.", HttpStatus.INTERNAL_SERVER_ERROR);
     }
 }

 @DeleteMapping("/api/admin/removeDoctorAppointmentSchedule/{doctorId}/{date}")
 public ResponseEntity<String> deleteDoctorAppointmentSchedule(@PathVariable long doctorId, @PathVariable String date) {
	 try {
		 LocalDate scheduleDate = LocalDate.parse(date, DateTimeFormatter.ISO_DATE);
     String result = appointmentService.removeDoctorAppointmentSchedule(doctorId,scheduleDate);
     return new ResponseEntity<>(result, HttpStatus.OK);
	 }
catch (Exception e) { 
         
         logger.error("Error retrieving Staff: ", e); 
        
         return new ResponseEntity<>("Staff with the details provided does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
     }
     } 

 @DeleteMapping("/api/admin/cancelAppointment/{appointmentId}")
 public ResponseEntity<String> cancelAppointment(@PathVariable long appointmentId) {
	 try {
		 
     String result = appointmentService.cancelAppointment(appointmentId);
     return new ResponseEntity<>(result, HttpStatus.OK);
	 }
catch (Exception e) { 
         
         logger.error("Error retrieving Staff: ", e); 
        
         return new ResponseEntity<>("Staff with the details provided does not exists..", HttpStatus.INTERNAL_SERVER_ERROR);
     }
     } 
 
 @GetMapping("/api/staff/getAllAppointmentByDate/{date}")
 public ResponseEntity<List<Appointment>> getAllAppointmentByDate(@PathVariable LocalDate date) {
	 try {
     	
		List< Appointment> appointment = appointmentService.getAllAppointmentsByDate(date);
         return new ResponseEntity<>(appointment, HttpStatus.CREATED);
     }  catch (Exception e) { 
         
         logger.error("Error retrieving Staff: ", e); 
        
         return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
     }
     } 
 
 @GetMapping("/api/staff/getAllAppointmentByPatientId/{patientId}")
 public ResponseEntity<List<Appointment>> getAllAppointmentByPatientId(@PathVariable long patientId) {
	 try {
     	
		List< Appointment> appointment = appointmentService.getAllAppointmentsByPatientId(patientId);
         return new ResponseEntity<>(appointment, HttpStatus.CREATED);
     }  catch (Exception e) { 
         
         logger.error("Error retrieving Staff: ", e); 
        
         return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
     }
     } 
 @GetMapping("/api/staff/getAllAppointmentByDoctorId/{doctorId}")
 public ResponseEntity<List<Appointment>> getAllAppointmentByDoctorId(@PathVariable long doctorId) {
	 try {
     	
		List< Appointment> appointment = appointmentService.getAllAppointmentsByDoctorId(doctorId);
         return new ResponseEntity<>(appointment, HttpStatus.CREATED);
     }  catch (Exception e) { 
         
         logger.error("Error retrieving Staff: ", e); 
        
         return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
     }
     } 
 @GetMapping("/api/staff/getAllAppointmentByDoctorIdAndDate/{doctorId}/{date}")
 public ResponseEntity<List<Appointment>> getAllAppointmentByDoctorIdAndDate(@PathVariable long doctorId,@PathVariable LocalDate date) {
	 try {
     	
		List< Appointment> appointment = appointmentService.getAllAppointmentsByDoctorIdAndDate(doctorId,date);
         return new ResponseEntity<>(appointment, HttpStatus.CREATED);
     }  catch (Exception e) { 
         
         logger.error("Error retrieving Staff: ", e); 
        
         return new ResponseEntity<>( HttpStatus.INTERNAL_SERVER_ERROR);
     }
     } 
 
}
