package com.example.hospital.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

@Entity
public class StaffPerformance {
    @Id
    @NotNull(message = "Staff ID is required")
    private long staffId;

    @NotNull(message = "Number of patients seen is required")
    private int patientsSeen;

    @NotNull(message = "Feedback score is required")
    private double feedbackScore;

    @NotNull(message = "Work hours are required")
    private double workHours;

    private double efficiencyRating;

    public StaffPerformance() {}

    public StaffPerformance(long staffId, int patientsSeen, double feedbackScore, double workHours) {
        this.staffId = staffId;
        this.patientsSeen = patientsSeen;
        this.feedbackScore = feedbackScore;
        this.workHours = workHours;
        calculateEfficiencyRating();
    }

    @Override
    public String toString() {
        return "StaffPerformance [staffId=" + staffId + ", patientsSeen=" + patientsSeen +
               ", feedbackScore=" + feedbackScore + ", workHours=" + workHours +
               ", efficiencyRating=" + efficiencyRating + "]";
    }

    public long getStaffId() {
        return staffId;
    }

    public void setStaffId(long staffId) {
        this.staffId = staffId;
    }

    public int getPatientsSeen() {
        return patientsSeen;
    }

    public void setPatientsSeen(int patientsSeen) {
        this.patientsSeen = patientsSeen;
        calculateEfficiencyRating();
    }

    public double getFeedbackScore() {
        return feedbackScore;
    }

    public void setFeedbackScore(double feedbackScore) {
        this.feedbackScore = feedbackScore;
    }

    public double getWorkHours() {
        return workHours;
    }

    public void setWorkHours(double workHours) {
        this.workHours = workHours;
        calculateEfficiencyRating();
    }

    public double getEfficiencyRating() {
        return efficiencyRating;
    }

    public void calculateEfficiencyRating() {
        if (workHours > 0) {
            this.efficiencyRating = patientsSeen / workHours;
        } else {
            this.efficiencyRating = 0;
        }
    }
}
