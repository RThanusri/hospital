package com.example.hospital.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
public class StaffAttendance {
    @Id
    @NotNull(message = "Staff ID is required")
    private long staffId;

    @NotNull(message = "Date is required")
    private LocalDate date;

    @NotNull(message = "Entry time is required")
    private LocalTime entryTime;

    
    private LocalTime exitTime;

    public StaffAttendance() {}

    public StaffAttendance(long staffId, LocalDate date, LocalTime entryTime, LocalTime exitTime) {
        this.staffId = staffId;
        this.date = date;
        this.entryTime = entryTime;
        this.exitTime = exitTime;
    }

    public long getStaffId() {
        return staffId;
    }

    public void setStaffId(long staffId) {
        this.staffId = staffId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalTime getEntryTime() {
        return entryTime;
    }

    public void setEntryTime(LocalTime entryTime) {
        this.entryTime = entryTime;
    }

    public LocalTime getExitTime() {
        return exitTime;
    }

    public void setExitTime(LocalTime exitTime) {
        this.exitTime = exitTime;
    }

    @Override
    public String toString() {
        return "StaffAttendance [staffId=" + staffId + ", date=" + date + 
               ", entryTime=" + entryTime + ", exitTime=" + exitTime + "]";
    }
}
