package com.example.hospital.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.example.hospital.Dao.PatientRepository;
import com.example.hospital.Entity.Appointment;
import com.example.hospital.Entity.Patient;
import com.example.hospital.Exception.PatientAlreadyExistsException;
import com.example.hospital.Exception.PatientNotExistsException;

import jakarta.validation.Valid;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    @Transactional
    public Patient registerPatient(Patient patient) {
        Patient existingPatient = patientRepository.findByEmail(patient.getEmail());
        if (existingPatient != null) {
        	
            throw new PatientAlreadyExistsException("Patient with this email already exists.");
        } 
        else {
        	System.out.println("Generated Patient ID: " + patient.getPatientId());
            Patient savedPatient =patientRepository.save(patient);
           
            return savedPatient;
            }
           
        }

	public String updatePatient(@Valid Patient patient, long patientId) {
		 Patient existingPatient = patientRepository.findByPatientId(patientId);
	        if (existingPatient == null) {
	        	
	            throw new PatientNotExistsException("Patient with this email does not exists.");
	        } 
	        else {
	        	
	        	   existingPatient.setName(patient.getName());
	               existingPatient.setDateOfBirth(patient.getDateOfBirth());
	               existingPatient.setAge(patient.getAge());
	               existingPatient.setPhoneNumber(patient.getPhoneNumber());
	               existingPatient.setGender(patient.getGender());
	               existingPatient.setAddress(patient.getAddress());
	              
	               Patient savedPatient = patientRepository.save(existingPatient);
	               
	           
	               return "Patient updated successfully: " ;
	           }
	}

	public Patient getPatient(long patientId) {
		Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new PatientNotExistsException("Patient with this email does not exists."));
        return patient;
		
	}

	public String removePatient(long patientId) {
		
		if(patientRepository.existsById(patientId))
		{
			patientRepository.deleteById(patientId);
			return"Patient Removed Successfully";
		}
		return "Patient does not exists";
	}

	public List<Patient> getAllPatient() {
	
		 return patientRepository.findAll().stream()
	                
	                .collect(Collectors.toList());
	    }
	}
    
