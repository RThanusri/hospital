package com.example.hospital.Enum;

public enum StaffRole {
	DOCTOR,
	NURSE,
	ADMINISTRATIVE_STAFF

}
