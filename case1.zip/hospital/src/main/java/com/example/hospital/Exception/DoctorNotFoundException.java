package com.example.hospital.Exception;

public class DoctorNotFoundException  extends RuntimeException  {

	
	public DoctorNotFoundException()
	{
		super("Doctor with the details provided does not Exists");
	}
	public DoctorNotFoundException(String message)
	{
		super(message);
	}
}

