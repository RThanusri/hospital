package com.example.hospital.Exception;

public class MedicalHistoryNotFoundException extends RuntimeException {


		

				
				public  MedicalHistoryNotFoundException ()
				{
					super("MedicalHistory with this ID do not exist");
				}
				public  MedicalHistoryNotFoundException (String message)
				{
					super(message);
				}


			}







