package com.example.hospital.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hospital.Dao.StaffPerformanceRepository;
import com.example.hospital.Dao.StaffRepository;
import com.example.hospital.Entity.Patient;
import com.example.hospital.Entity.Staff;
import com.example.hospital.Entity.StaffPerformance;
import com.example.hospital.Exception.PatientNotExistsException;
import com.example.hospital.Exception.StaffAlreadyExistsException;
import com.example.hospital.Exception.StaffNotExistsException;

import jakarta.validation.Valid;

@Service
public class StaffPerformanceService {
	@Autowired
	private StaffRepository staffRepository;
	
	@Autowired
	private StaffPerformanceRepository staffPerformanceRepository;

	public StaffPerformance inputStaffPerformance(@Valid StaffPerformance staffPerformance) {
		Staff existingStaff = staffRepository.findById(staffPerformance.getStaffId()).orElse(null);
		  if (existingStaff == null) {
	        	
	            throw new StaffNotExistsException("Staff with the details provided does not  exists.");
	        } 
	        else {
	        
	        	StaffPerformance savedStaffPerformance =staffPerformanceRepository.save(staffPerformance);
	           
	            return savedStaffPerformance;
	            }
	           
	        }

	public String updateStaffPerformance(@Valid StaffPerformance staffPerformance, long staffId) {
	   
	        StaffPerformance  existingStaffPerformance = staffPerformanceRepository.findById(staffId).orElse(null);
	        if(existingStaffPerformance==null)
	        {
	        	throw new StaffNotExistsException("Staff with the details provided does not  exists.");
	        } 
	        else {
	        		
	            existingStaffPerformance.setPatientsSeen(staffPerformance.getPatientsSeen());
	            existingStaffPerformance.setFeedbackScore(staffPerformance.getFeedbackScore());
	            existingStaffPerformance.setWorkHours(staffPerformance.getWorkHours());
	            
	            existingStaffPerformance.calculateEfficiencyRating();
	             staffPerformanceRepository.save(existingStaffPerformance);
	             return "Staff performance updated succesfully";
	        }
	}

	public StaffPerformance getStaffPerformance(long staffId) {
		StaffPerformance staffPerformance = staffPerformanceRepository.findById(staffId)
                .orElseThrow(() -> new StaffNotExistsException("Staff with this email does not exists."));
        return staffPerformance;
	}

	public String removeStaffPerformance(long staffId) {
		if(staffPerformanceRepository.existsByStaffId(staffId))
		{
			staffPerformanceRepository.deleteByStaffId(staffId);
			return"Attendance Removed Successfully";
		}
		return "Attendance Record  with the details provided does not exists.";
	}

	
	public List<StaffPerformance> getAllStaffPerformance() {
		 return staffPerformanceRepository.findAll().stream()
	                
	                .collect(Collectors.toList());
	
	}
	       
	}
    
	


