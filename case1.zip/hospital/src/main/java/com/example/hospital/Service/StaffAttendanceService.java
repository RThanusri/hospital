package com.example.hospital.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hospital.Dao.StaffAttendanceRepository;
import com.example.hospital.Dao.StaffRepository;
import com.example.hospital.Entity.Staff;
import com.example.hospital.Entity.StaffAttendance;
import com.example.hospital.Exception.StaffNotExistsException;

import jakarta.transaction.Transactional;

@Service
public class StaffAttendanceService {
	
	@Autowired
	private StaffRepository staffRepository;
	@Autowired
	private StaffAttendanceRepository staffAttendanceRepository;
	

	public void recordCheckIn(StaffAttendance attendance) {
		Staff staff=staffRepository.findById(attendance.getStaffId()).orElse(null);
		if(staff==null)
		{
			throw new StaffNotExistsException();
		}
		else
		{
			staffAttendanceRepository.save(attendance);
		}
		
	}


	public void recordCheckOut(StaffAttendance attendance) {
		
		staffAttendanceRepository.save(attendance);
	}


	public StaffAttendance findStaffAttendanceByStaffIdAndDate(long staffId, LocalDate now) {
	
		return staffAttendanceRepository.findByStaffIdAndDate(staffId,now);
	}

	@Transactional
	public String removeAttendance(long id, LocalDate date) {
		if(staffAttendanceRepository.existsByStaffIdAndDate(id,date))
		{
			staffAttendanceRepository.deleteByStaffIdAndDate(id,date);
			return"Attendance Removed Successfully";
		}
		return "Attendance Record  with the details provided does not exists.";
	}


	public List<StaffAttendance> getAllStaffAttendanceById(long staffId) {
		 return staffAttendanceRepository.findAllByStaffId(staffId).stream()
	                
	                .collect(Collectors.toList());
	
	}


	public List<StaffAttendance> getAllStaffAttendanceByDate(LocalDate date) {
		return staffAttendanceRepository.findAllByDate(date).stream()
                
                .collect(Collectors.toList());
	}


	public List<StaffAttendance> getAllStaffAttendanceByDateAndId(LocalDate date, Long staffId) {
		
return staffAttendanceRepository.findAllByDateAndStaffId(date,staffId).stream()
                
                .collect(Collectors.toList());
	}
	
}
