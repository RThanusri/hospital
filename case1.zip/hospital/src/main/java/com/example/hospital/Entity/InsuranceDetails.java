package com.example.hospital.Entity;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
public class InsuranceDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

   

	@NotNull(message = "Policy number cannot be null")
    private long policyNumber;

    @Min(value = 0, message = "Insurance amount must be positive")
    private long coverageAmount;

    @NotBlank(message = "Provider name cannot be blank")
    private String insuranceProvider;

   
    private long patientId;
  
    public InsuranceDetails()
    {
    	
    }
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(long policyNumber) {
        this.policyNumber = policyNumber;
    }

    public long getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(long coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public String getInsuranceProvider() {
        return insuranceProvider;
    }

    public void setInsuranceProvider(String insuranceProvider) {
        this.insuranceProvider = insuranceProvider;
    }
	public long getPatientId() {
		return patientId;
	}
	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}
	public InsuranceDetails(long id, @NotNull(message = "Policy number cannot be null") long policyNumber,
			@Min(value = 0, message = "Insurance amount must be positive") long coverageAmount,
			@NotBlank(message = "Provider name cannot be blank") String insuranceProvider, long patientId) {
		super();
		this.id = id;
		this.policyNumber = policyNumber;
		this.coverageAmount = coverageAmount;
		this.insuranceProvider = insuranceProvider;
		this.patientId = patientId;
	}
	@Override
	public String toString() {
		return "InsuranceDetails [id=" + id + ", policyNumber=" + policyNumber + ", coverageAmount=" + coverageAmount
				+ ", insuranceProvider=" + insuranceProvider + ", patientId=" + patientId + "]";
	}

 
}
