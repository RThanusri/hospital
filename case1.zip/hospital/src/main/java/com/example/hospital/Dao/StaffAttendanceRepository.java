package com.example.hospital.Dao;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.hospital.Entity.Staff;
import com.example.hospital.Entity.StaffAttendance;

@Repository
public interface StaffAttendanceRepository extends JpaRepository<StaffAttendance,Long>{

	StaffAttendance findByStaffIdAndDate(long staffId, LocalDate now);

	boolean existsByStaffIdAndDate(long id, LocalDate date);

	void deleteByStaffIdAndDate(long id,LocalDate date);

	Optional<StaffAttendance> findAllByStaffId(long staffId);

	Optional<StaffAttendance> findAllByDate(LocalDate date);

	Optional<StaffAttendance> findAllByDateAndStaffId(LocalDate date, Long staffId);

}
