package com.example.hospital.Entity;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;

@Entity
public class DoctorAppointmentSchedule {
	
	
	    @Id
	    

	    @NotNull
	    private long doctorId;

	    @NotNull
	    private LocalDate date;

	    @NotNull
	    private LocalTime startTime;

	    @NotNull
	    private LocalTime endTime;

		public long getDoctorId() {
			return doctorId;
		}

		public void setDoctorId(long doctorId) {
			this.doctorId = doctorId;
		}

		public LocalDate getDate() {
			return date;
		}

		public void setDate(LocalDate date) {
			this.date = date;
		}

		public LocalTime getStartTime() {
			return startTime;
		}

		public void setStartTime(LocalTime startTime) {
			this.startTime = startTime;
		}

		public LocalTime getEndTime() {
			return endTime;
		}

		public void setEndTime(LocalTime endTime) {
			this.endTime = endTime;
		}
		public DoctorAppointmentSchedule()
		{
			
		}
		public DoctorAppointmentSchedule(@NotNull long doctorId, @NotNull LocalDate date, @NotNull LocalTime startTime,
				@NotNull LocalTime endTime) {
			super();
			this.doctorId = doctorId;
			this.date = date;
			this.startTime = startTime;
			this.endTime = endTime;
		}

		@Override
		public String toString() {
			return "DoctorAppointmentSchedule [doctorId=" + doctorId + ", date=" + date + ", startTime=" + startTime
					+ ", endTime=" + endTime + "]";
		}

	
	

}
