package com.example.hospital.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;

import com.example.hospital.Enum.StaffRole;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class Staff {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @NotBlank(message = "Staff name is required")
    private String name;

    @NotNull(message = "Role is required")
    @Enumerated(EnumType.STRING)
    private StaffRole staffRole;

    @NotBlank(message = "Contact information is required")
    private String contactInfo;

    @NotNull(message = "Salary details are required")
    private double salaryAmount;

    @NotNull(message = "Employment start date is required")
    private LocalDate employmentStartDate;

    @NotBlank(message = "Specialization is required for certain roles")
    private String specialization;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public StaffRole getStaffRole() {
		return staffRole;
	}

	public void setStaffRole(StaffRole staffRole) {
		this.staffRole = staffRole;
	}

	public String getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(String contactInfo) {
		this.contactInfo = contactInfo;
	}

	public double getSalaryAmount() {
		return salaryAmount;
	}

	public void setSalaryAmount(double salaryAmount) {
		this.salaryAmount = salaryAmount;
	}

	public LocalDate getEmploymentStartDate() {
		return employmentStartDate;
	}

	public void setEmploymentStartDate(LocalDate employmentStartDate) {
		this.employmentStartDate = employmentStartDate;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	@Override
	public String toString() {
		return "Staff [id=" + id + ", name=" + name + ", staffRole=" + staffRole + ", contactInfo=" + contactInfo
				+ ", salaryAmount=" + salaryAmount + ", employmentStartDate=" + employmentStartDate
				+ ", specialization=" + specialization + "]";
	}
public Staff()
{
	
}
	public Staff(long id, @NotBlank(message = "Staff name is required") String name,
			@NotNull(message = "Role is required") StaffRole staffRole,
			@NotBlank(message = "Contact information is required") String contactInfo,
			@NotNull(message = "Salary details are required") double salaryAmount,
			@NotNull(message = "Employment start date is required") LocalDate employmentStartDate,
			@NotBlank(message = "Specialization is required for certain roles") String specialization) {
		super();
		this.id = id;
		this.name = name;
		this.staffRole = staffRole;
		this.contactInfo = contactInfo;
		this.salaryAmount = salaryAmount;
		this.employmentStartDate = employmentStartDate;
		this.specialization = specialization;
	}


}
