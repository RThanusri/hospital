package com.example.hospital.Dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.hospital.Entity.DoctorAppointmentSchedule;

@Repository
public interface DoctorAppointmentScheduleRepository extends JpaRepository<DoctorAppointmentSchedule,Long> {

	DoctorAppointmentSchedule findByDoctorIdAndDate(long doctorId, LocalDate date);

	void deleteByDoctorIdAndDate(long doctorId, LocalDate scheduleDate);

	List<DoctorAppointmentSchedule> findAllByDoctorId(long doctorId);

}
