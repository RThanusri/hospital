package com.example.hospital.Exception;

public class InsuranceNotFoundException  extends RuntimeException {


	

			
			public  InsuranceNotFoundException()
			{
				super("Insurance details with this ID do not exist");
			}
			public  InsuranceNotFoundException(String message)
			{
				super(message);
			}


		}




