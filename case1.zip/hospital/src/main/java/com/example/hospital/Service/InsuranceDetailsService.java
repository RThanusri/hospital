package com.example.hospital.Service;



import com.example.hospital.Dao.InsuranceDetailsRepository;
import com.example.hospital.Dao.PatientRepository;
import com.example.hospital.Entity.InsuranceDetails;
import com.example.hospital.Entity.Patient;
import com.example.hospital.Exception.InsuranceNotFoundException;
import com.example.hospital.Exception.PatientNotExistsException;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InsuranceDetailsService {

    @Autowired
    private InsuranceDetailsRepository insuranceDetailsRepository;
    
    @Autowired
    private PatientRepository  patientRepository;

    public InsuranceDetails saveInsuranceDetails(InsuranceDetails insuranceDetails) {
    	
  Patient patient= patientRepository.findByPatientId(insuranceDetails.getPatientId());
  if(patient==null)
  {
	  throw new PatientNotExistsException();
  }
  else {
        return insuranceDetailsRepository.save(insuranceDetails);
    }
}

    public String updateInsuranceInfo(@Valid InsuranceDetails insurance, long id) {
      
        InsuranceDetails existingInsurance = insuranceDetailsRepository.findById(id).orElse(null);

        if (existingInsurance == null) {
            
            throw new InsuranceNotFoundException("Insurance details with this ID do not exist.");
        } else {
       
            existingInsurance.setPolicyNumber(insurance.getPolicyNumber());
            existingInsurance.setCoverageAmount(insurance.getCoverageAmount());
            existingInsurance.setInsuranceProvider(insurance.getInsuranceProvider());
            existingInsurance.setPatientId(insurance.getPatientId());

            
            InsuranceDetails savedInsurance = insuranceDetailsRepository.save(existingInsurance);

            return "Insurance details updated successfully:";
        }
    }

	public InsuranceDetails getInsuranceDetailsById(long id) {
		InsuranceDetails insuranceDetails = insuranceDetailsRepository.findById(id)
                .orElseThrow(() -> new InsuranceNotFoundException("Insurance details with this ID do not exist."));
        return  insuranceDetails;
	
		
	}

	public String removeInsuranceDetails(long id) {
		if(insuranceDetailsRepository.existsById(id))
		{
			insuranceDetailsRepository.deleteById(id);
			return"insuranceDetails Removed Successfully";
		}
		return "Insurance details with this ID do not exist.";
	}
	
}