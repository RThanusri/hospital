package com.example.hospital.Exception;

public class StaffNotExistsException extends RuntimeException  {

	
	public StaffNotExistsException()
	{
		super("Staff with the details provided does not Exists");
	}
	public StaffNotExistsException(String message)
	{
		super(message);
	}
}
