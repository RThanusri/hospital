package com.example.hospital.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.hospital.Entity.StaffPerformance;

@Repository

public interface StaffPerformanceRepository extends JpaRepository<StaffPerformance,Long>{

	boolean existsByStaffId(long staffId);

	void deleteByStaffId(long staffId);

}
