package com.example.hospital.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.hospital.Dao.StaffRepository;
import com.example.hospital.Entity.Patient;
import com.example.hospital.Entity.Staff;
import com.example.hospital.Exception.PatientAlreadyExistsException;
import com.example.hospital.Exception.PatientNotExistsException;
import com.example.hospital.Exception.StaffAlreadyExistsException;
import com.example.hospital.Exception.StaffNotExistsException;

import jakarta.validation.Valid;

@Service
public class StaffService {
	
	@Autowired
	private StaffRepository staffRepository;

	 @Transactional
	    public Staff registerStaff(Staff staff) {
		 Staff existingStaff = staffRepository.findByContactInfo(staff.getContactInfo());
	        if (existingStaff != null) {
	        	
	            throw new StaffAlreadyExistsException("Staff with the details provided already exists.");
	        } 
	        else {
	        
	        	Staff savedStaff =staffRepository.save(staff);
	           
	            return savedStaff;
	            }
	           
	        }

	 public String updateStaff(Staff staff, long id) {

		    Staff existingStaff = staffRepository.findById(id).orElse(null);

		    if (existingStaff == null) {
		        throw new StaffNotExistsException("Staff with the details provided does not exist.");
		    } else {
		        
		        existingStaff.setName(staff.getName());
		        existingStaff.setStaffRole(staff.getStaffRole());
		        existingStaff.setContactInfo(staff.getContactInfo());
		        existingStaff.setSalaryAmount(staff.getSalaryAmount());
		        existingStaff.setEmploymentStartDate(staff.getEmploymentStartDate());
		        existingStaff.setSpecialization(staff.getSpecialization());

		
		        staffRepository.save(existingStaff);

		        return "Staff details updated successfully";
		    }
		}

	public Staff getStaff(long id) {
		
		Staff	staff =staffRepository.findById(id)
                .orElseThrow(() -> new StaffNotExistsException("Staff with the details provided does not exists."));
        return staff;
	}

	public String removeStaff(long id) {
		if(staffRepository.existsById(id))
		{
			staffRepository.deleteById(id);
			return"Staff Removed Successfully";
		}
		return "Staff with the details provided does not exists.";
	}

	public List<Staff> getAllStaff() {
		 return staffRepository.findAll().stream()
	                
	                .collect(Collectors.toList());
	    }
		
	}
		

