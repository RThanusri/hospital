package com.example.hospital.Exception;

public class PatientNotExistsException extends RuntimeException  {

		
		public PatientNotExistsException()
		{
			super("Patient with the details provided does not Exists");
		}
		public PatientNotExistsException(String message)
		{
			super(message);
		}


	}


