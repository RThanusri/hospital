package com.example.hospital.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
public class StaffSchedule {
    @Id
    @NotNull(message = "Staff ID is required")
    private long staffId;

    @NotNull(message = "Shift start time is required")
    private LocalDateTime shiftStart;

    @NotNull(message = "Shift end time is required")
    private LocalDateTime shiftEnd;

    @NotBlank(message = "Tasks are required")
    private String tasks;

    public StaffSchedule() {}

    public StaffSchedule(long staffId, LocalDateTime shiftStart, LocalDateTime shiftEnd, String tasks) {
        this.staffId = staffId;
        this.shiftStart = shiftStart;
        this.shiftEnd = shiftEnd;
        this.tasks = tasks;
    }

    @Override
    public String toString() {
        return "StaffSchedule [staffId=" + staffId + ", shiftStart=" + shiftStart + ", shiftEnd=" + shiftEnd
                + ", tasks=" + tasks + "]";
    }

    public long getStaffId() {
        return staffId;
    }

    public void setStaffId(long staffId) {
        this.staffId = staffId;
    }

    public LocalDateTime getShiftStart() {
        return shiftStart;
    }

    public void setShiftStart(LocalDateTime shiftStart) {
        this.shiftStart = shiftStart;
    }

    public LocalDateTime getShiftEnd() {
        return shiftEnd;
    }

    public void setShiftEnd(LocalDateTime shiftEnd) {
        this.shiftEnd = shiftEnd;
    }

    public String getTasks() {
        return tasks;
    }

    public void setTasks(String tasks) {
        this.tasks = tasks;
    }
}
