package com.example.hospital.Entity;


import java.time.LocalDate;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


@Entity
public class MedicalHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long medicalHistoryId;

    @NotBlank(message = "Allergies information is mandatory")
    @Size(max = 255, message = "Allergies information must be less than 255 characters")
    private String allergies;

    @NotBlank(message = "Disease information is mandatory")
    @Size(max = 255, message = "Disease information must be less than 255 characters")
    private String knownDiseases;

    @NotBlank(message = "Treatment taken information is mandatory")
    @Size(max = 255, message = "Treatment taken information must be less than 255 characters")
    private String pastTreatments;

    @NotBlank(message = "Ongoing treatment information is mandatory")
    @Size(max = 255, message = "Ongoing treatment information must be less than 255 characters")
    private String currentTreatments; 

    @NotNull(message = "Last check-up date is mandatory")
    private LocalDate lastCheckUpDate;

    
    @NotBlank(message = "Family medical history is mandatory")
    @Size(max = 255, message = "Family medical history must be less than 255 characters")
    private String familyMedicalHistory;
   
   
    private long patientId;
    public MedicalHistory()
    {
    	
    }
	
	public long getMedicalHistoryId() {
		return medicalHistoryId;
	}

	public void setMedicalHistoryId(long medicalHistoryId) {
		this.medicalHistoryId = medicalHistoryId;
	}

	public String getAllergies() {
		return allergies;
	}

	public void setAllergies(String allergies) {
		this.allergies = allergies;
	}

	public String getKnownDiseases() {
		return knownDiseases;
	}

	public void setKnownDiseases(String knownDiseases) {
		this.knownDiseases = knownDiseases;
	}

	public String getPastTreatments() {
		return pastTreatments;
	}

	public void setPastTreatments(String pastTreatments) {
		this.pastTreatments = pastTreatments;
	}

	public String getCurrentTreatments() {
		return currentTreatments;
	}

	public void setCurrentTreatments(String currentTreatments) {
		this.currentTreatments = currentTreatments;
	}

	public LocalDate getLastCheckUpDate() {
		return lastCheckUpDate;
	}

	public void setLastCheckUpDate(LocalDate lastCheckUpDate) {
		this.lastCheckUpDate = lastCheckUpDate;
	}

	public String getFamilyMedicalHistory() {
		return familyMedicalHistory;
	}

	public void setFamilyMedicalHistory(String familyMedicalHistory) {
		this.familyMedicalHistory = familyMedicalHistory;
	}

	@Override
	public String toString() {
		return "MedicalHistory [medicalHistoryId=" + medicalHistoryId + ", allergies=" + allergies + ", knownDiseases="
				+ knownDiseases + ", pastTreatments=" + pastTreatments + ", currentTreatments=" + currentTreatments
				+ ", lastCheckUpDate=" + lastCheckUpDate + ", familyMedicalHistory=" + familyMedicalHistory
				+ ", patientId=" + patientId + "]";
	}

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	
    
}

