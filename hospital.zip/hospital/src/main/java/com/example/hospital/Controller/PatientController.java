package com.example.hospital.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.example.hospital.Entity.Patient;
import com.example.hospital.Service.PatientService;

import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
public class PatientController {

    private static final Logger logger = LoggerFactory.getLogger(PatientController.class);

    @Autowired
    private PatientService patientService;

    @PostMapping("/api/admin/registerPatient")
    public ResponseEntity<?> registerPatient(@RequestBody @Valid Patient patient) {
        try {
        	System.out.println("patient id" +patient.getPatientId() );
            Patient registeredPatient = patientService.registerPatient(patient);
            return new ResponseEntity<>(registeredPatient, HttpStatus.CREATED);
        } catch (Exception e) {
            logger.error("Error registering patient: ", e);
            return new ResponseEntity<>("An error occurred while registering the patient.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        String errorMessage = ex.getBindingResult().getAllErrors().get(0).getDefaultMessage();
        logger.error("Validation error: " + errorMessage);
        return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
    }
}
