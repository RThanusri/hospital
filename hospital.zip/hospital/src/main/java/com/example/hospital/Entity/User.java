package com.example.hospital.Entity;

import java.util.Collection;

import org.aspectj.apache.bcel.generic.Type;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;

@Entity

public class User implements UserDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userId;

	@NotEmpty(message="User Name cannot be Null...Provide a User Name")
	@Pattern(regexp="^[a-zA-Z0-9_-]{3,40}$",message="Username must be between 3 and 20 characters long and can include letters, numbers, underscores, and hyphens.")
	private String userName;
	
	private String password;


    @NotEmpty(message = "Email cannot be empty.")
    @Email(message = "Invalid email format. Please enter a valid email address.")
    private String email;


	public long getUserId() {
		return userId;
	}


	public void setUserId(long userId) {
		this.userId = userId;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", password=" + password + ", email=" + email
				+ "]";
	}

public User()
{
	
}
	public User(long userId,
			@NotEmpty(message = "User Name cannot be Null...Provide a User Name") @Pattern(regexp = "^[a-zA-Z0-9_-]{3,40}$", message = "Username must be between 3 and 20 characters long and can include letters, numbers, underscores, and hyphens.") String userName,
			String password,
			@NotEmpty(message = "Email cannot be empty.") @Email(message = "Invalid email format. Please enter a valid email address.") String email) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.email = email;
	}


	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return null;
	}
}