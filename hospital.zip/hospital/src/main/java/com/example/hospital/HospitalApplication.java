package com.example.hospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalApplication.class, args);
	}

}
{
"name": "John",

 "password": "Password123",
 "email": "swetha@example.com",
 "role":"ADMIN"
  
  
 
  
  
}
{
	   
	  "name": "John Doe",
	  "dateOfBirth": "1990-01-01",
	  "age": 30,
	  "phoneNumber": "1234567890",
	  "gender": "Male",
	  "email": "john.doe@example.com",
	  "address": "123 Main St, Anytown, USA"
	  
	  
	}

{
	  "email": "swetha@example.com",
	  "password": "Password123"
	  
	  
	}


