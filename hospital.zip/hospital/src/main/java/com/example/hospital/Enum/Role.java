package com.example.hospital.Enum;

public enum Role {
		STAFF,
		ADMIN
		

	


}
