package com.example.hospital.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.hospital.Entity.AuthenticationRequest;
import com.example.hospital.Entity.AuthenticationResponse;
import com.example.hospital.Entity.SignupRequest;
import com.example.hospital.Entity.User;
import com.example.hospital.Service.AuthService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.Valid;

@RestController

public class UserController {
	




	@Autowired
    private  AuthService authService;

	@PostMapping("/api/auth/signup")
	public ResponseEntity<?> signup(@RequestBody @Valid SignupRequest signupRequest) {
	    try {
	        System.out.println("Signup request received: " + signupRequest);

	        
	        System.out.println("Email: " + signupRequest.getEmail());
	        System.out.println("Password: " + signupRequest.getPassword());
	        
	        System.out.println("User Name: " + signupRequest.getUserName());

	        

	        User createdCustomerDto = authService.createUser(signupRequest);

	        if (createdCustomerDto == null) {
	            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	        }

	        return new ResponseEntity<>(createdCustomerDto, HttpStatus.CREATED);
	    } catch (Exception e) { 
	        System.err.println("Error during signup: " + e.getMessage());
	        e.printStackTrace();
	        return new ResponseEntity<>("Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}


	@PostMapping("/api/auth/login")
    public ResponseEntity<AuthenticationResponse> login(@RequestBody AuthenticationRequest authenticationRequest) {
        try {
            AuthenticationResponse response = authService.login(authenticationRequest);
            return ResponseEntity.ok(response);
        } catch (BadCredentialsException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null); 
        }
	}
	

}


