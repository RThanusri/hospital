package com.example.hospital.Entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;

public class SignupRequest {
	


	@NotEmpty(message="User Name cannot be null")
	private String userName;
	@NotEmpty(message="Password cannot be null")
	private String password;

 

	@NotEmpty(message="email cannot be null")
	@Email(message="Invalid email format")
	private String email;




	public String getUserName() {
		return userName;
	}




	public void setUserName(String userName) {
		this.userName = userName;
	}




	public String getPassword() {
		return password;
	}




	public void setPassword(String password) {
		this.password = password;
	}




	public String getEmail() {
		return email;
	}




	public void setEmail(String email) {
		this.email = email;
	}




	@Override
	public String toString() {
		return "SignupRequest [userName=" + userName + ", password=" + password + ", email=" + email + "]";
	}




	public SignupRequest(String userName, String password, String email) {
		super();
		this.userName = userName;
		this.password = password;
		this.email = email;
	}

}