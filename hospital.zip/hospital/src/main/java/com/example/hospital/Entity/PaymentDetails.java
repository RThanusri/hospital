package com.example.hospital.Entity;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

@Entity
public class PaymentDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long paymentId;

    @NotNull(message = "Amount paid cannot be null")
    @Min(value = 0, message = "Amount paid must be non-negative")
    private long amountPaid;

    @NotNull(message = "Amount pending cannot be null")
    @Min(value = 0, message = "Amount pending must be non-negative")
    private long amountPending;

    
    private long patientId;

	public long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(long paymentId) {
		this.paymentId = paymentId;
	}

	public long getAmountPaid() {
		return amountPaid;
	}

	public void setAmountPaid(long amountPaid) {
		this.amountPaid = amountPaid;
	}

	public long getAmountPending() {
		return amountPending;
	}

	public void setAmountPending(long amountPending) {
		this.amountPending = amountPending;
	}

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public PaymentDetails(long paymentId,
			@NotNull(message = "Amount paid cannot be null") @Min(value = 0, message = "Amount paid must be non-negative") long amountPaid,
			@NotNull(message = "Amount pending cannot be null") @Min(value = 0, message = "Amount pending must be non-negative") long amountPending,
			long patientId) {
		super();
		this.paymentId = paymentId;
		this.amountPaid = amountPaid;
		this.amountPending = amountPending;
		this.patientId = patientId;
	}

	@Override
	public String toString() {
		return "PaymentDetails [paymentId=" + paymentId + ", amountPaid=" + amountPaid + ", amountPending="
				+ amountPending + ", patientId=" + patientId + "]";
	}

    
}