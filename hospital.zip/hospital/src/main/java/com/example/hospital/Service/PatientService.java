package com.example.hospital.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.hospital.Dao.PatientRepository;
import com.example.hospital.Entity.Appointment;
import com.example.hospital.Entity.Patient;
import com.example.hospital.Exception.PatientAlreadyExistsException;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    @Transactional
    public Patient registerPatient(Patient patient) {
        Patient existingPatient = patientRepository.findByEmail(patient.getEmail());
        if (existingPatient != null) {
            throw new PatientAlreadyExistsException("Patient with this email already exists.");
        } else {
        	System.out.println("Generated Patient ID: " + patient.getPatientId());
            Patient savedPatient =patientRepository.save(patient);
           
            return savedPatient;
            }
           
        }
    
}